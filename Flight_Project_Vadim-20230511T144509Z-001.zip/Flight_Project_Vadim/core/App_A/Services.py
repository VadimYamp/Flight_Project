from App_A.Data_Layer import *

class flights_service():
    pass

