#!/bin/bash

# Get a list of SQL dump files in the /db-dumps directory
FILES=/db-dumps/*.sql

# Loop through the files and import them into the MySQL server
for f in $FILES
do
  echo "Importing file: $f"
  mysql -uroot -p$MYSQL_ROOT_PASSWORD < "$f"
done