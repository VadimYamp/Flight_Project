echo "Start Django init"
python core/manage.py runserver localhost:8000
#python manage.py makemigrations App_A
#python manage.py migrate App_A
echo "Stop Django init"