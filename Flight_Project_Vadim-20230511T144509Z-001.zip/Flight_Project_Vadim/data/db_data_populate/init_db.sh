echo "Start DB init"
#mysql -u root flight_db < /db_data/flight_db_app_a_n1_users.sql
#mysql -u root flight_db < /db_data/flight_db_app_a_n2_customers.sql
#mysql -u root flight_db < /db_data/flight_db_app_a_n3_airline_companies.sql
#mysql -u root flight_db < /db_data/flight_db_app_a_n4_administrators.sql
#mysql -u root flight_db < /db_data/flight_db_app_a_n5_user_roles.sql
#mysql -u root flight_db < /db_data/flight_db_app_a_n6_countries.sql
#mysql -u root flight_db < /db_data/flight_db_app_a_n7_flights.sql
#mysql -u root flight_db < /db_data/flight_db_app_a_n8_tickets.sql
echo "Stop DB init"